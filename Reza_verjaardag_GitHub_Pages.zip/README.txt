REZA'S VERJAARDAG — GITHUB PAGES

Upload index.html, aiko-1.jpeg en aiko-2.jpeg naar je GitHub repository.

Daarna:
Settings → Pages → Deploy from a branch → main → / (root) → Save.

De uitnodiging is mobielvriendelijk en gebruikt de foto's van Aiko uit de chat.
